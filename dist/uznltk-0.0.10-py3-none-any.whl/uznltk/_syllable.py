import UzSyllable
def syllables(text):
    a= UzSyllable.syllables(text)
    return a
def hyphenation(text):
    a= UzSyllable.hyphenation(text)
    return a
def count(text):
    a= UzSyllable.count(text)
    return a

