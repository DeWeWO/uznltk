from UzMorphAnalyser import UzMorphAnalyser

# Avval obyekt yaratish kerak
analyser = UzMorphAnalyser()
def lemmatize(word):
    # So‘zni lemmatizatsiya qilish
    a=analyser.lemmatize(word)
    return a

